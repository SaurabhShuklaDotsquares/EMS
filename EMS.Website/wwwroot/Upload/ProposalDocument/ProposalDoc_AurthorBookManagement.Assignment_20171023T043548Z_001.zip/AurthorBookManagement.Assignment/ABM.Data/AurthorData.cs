﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ABM.Data
{
    public class AurthorDataClass
    {
        public Aurthor aurthor { get; set; }
        public Address address { get; set; }
        public Book book { get; set; }
    }

    
}
