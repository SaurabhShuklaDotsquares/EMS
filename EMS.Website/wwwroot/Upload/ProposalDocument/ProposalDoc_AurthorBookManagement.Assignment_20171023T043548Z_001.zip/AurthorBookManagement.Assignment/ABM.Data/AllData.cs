﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ABM.Data
{
    public class AllData
    {
        public static List<Aurthor> AurthorData;
        public static List<Book> BookData;
        public static List<Address> AddressData;
        
        static AllData()
        {
            AurthorData = new List<Aurthor>();
            BookData = new List<Book>();
            AddressData = new List<Address>();
        }
    }
}
