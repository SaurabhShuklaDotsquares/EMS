﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AurthorBookManagement.Assignment
{
    class Program
    {
        static void Main(string[] args)
        {
            TaskSelection taskSelection = new TaskSelection();
            taskSelection.selectOperation();
        }
    }
}
