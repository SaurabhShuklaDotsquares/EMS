﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ABM.Data;
using ABM.BusinessLibrary;
namespace AurthorBookManagement.Assignment
{
    public class TaskSelection
    {
        AurthorOperation aurthorOperation;
        AddressOperation addressOperation;
        BookOperation bookOperation;
        List<int> aurthorId;
        public TaskSelection()
        {
            aurthorOperation = new AurthorOperation();
            addressOperation = new AddressOperation();
            bookOperation = new BookOperation();
            aurthorId = new List<int>();

        }
        public void selectOperation()
        {
            int operationChoice;
            do
            {
                Console.WriteLine("\n----------------********************--------------\n");
                Console.WriteLine("Enter 1 to Add Aurthor");
                Console.WriteLine("Enter 2 to Add Book");
                Console.WriteLine("Enter 3 to Add Address");
                Console.WriteLine("Enter 4 to Edit Aurthor Detail");
                Console.WriteLine("Enter 5 to Edit Book Detail");
                Console.WriteLine("Enter 6 to show detail of Aurthor");
                Console.WriteLine("Enter 7 to show Detail of Books");
                Console.WriteLine("Enter 8 to show address detail of Aurthors");
                Console.WriteLine("Enter 0 to close");
                operationChoice = int.Parse(Console.ReadLine());
                switch (operationChoice)
                {
                    case 1:
                        Random random = new Random();
                        AurthorDataClass aurthorDataClass = new AurthorDataClass();

                        aurthorDataClass.aurthor = new Aurthor();
                        Console.WriteLine("Enter AurthorId");
                        aurthorDataClass.aurthor.AurthorId = int.Parse(Console.ReadLine());
                        List<int> aurthorIdList = new List<int>();
                        bool result = aurthorOperation.CheckaurthorId(aurthorDataClass.aurthor.AurthorId);

                        if (result==true)
                        {
                            Console.WriteLine("Aurthor Id {0} already exist", aurthorDataClass.aurthor.AurthorId);
                        }
                        else
                        {
                            Console.WriteLine("Enter Aurthor Name:");
                            aurthorDataClass.aurthor.Name = Console.ReadLine();
                            Console.WriteLine("Enter Aurthor Age:");
                            aurthorDataClass.aurthor.Age = int.Parse(Console.ReadLine());

                            aurthorDataClass.address = new Address();

                            aurthorDataClass.address.AddressId = random.Next(0, 999);
                            aurthorDataClass.address.AurthorId = aurthorDataClass.aurthor.AurthorId;
                            Console.WriteLine("Enter Country:");
                            aurthorDataClass.address.Country = Console.ReadLine();
                            Console.WriteLine("Enter City:");
                            aurthorDataClass.address.City = Console.ReadLine();

                            aurthorDataClass.book = new Book();

                            aurthorDataClass.book.BookId = random.Next(1000, 9999);
                            aurthorDataClass.book.AurthorId = aurthorDataClass.aurthor.AurthorId;
                            Console.WriteLine("Enter Book Name:");
                            aurthorDataClass.book.BookName = Console.ReadLine();
                            aurthorDataClass.book.AurthorId = aurthorDataClass.aurthor.AurthorId;
                            Console.WriteLine("Enter book publisher Name:");
                            aurthorDataClass.book.Publisher = Console.ReadLine();
                            aurthorOperation.AddAurthor(aurthorDataClass);
                        }



                        break;
                    case 2:
                        Book book = new Book();

                        book.BookId = new Random().Next(1000, 9999);
                        Console.WriteLine("Enter Book Name:");
                        book.BookName = Console.ReadLine();

                        aurthorId = aurthorOperation.GetAurthorId();
                        if (aurthorId.Count > 0)
                        {
                            Console.WriteLine("List of available aurthor");
                            foreach (var item in aurthorId)
                            {
                                Console.WriteLine("Aurthor Id: {0}", item);
                            }
                        }
                        Console.WriteLine("Enter Aurthor Id from available aurthors:");
                        book.AurthorId = int.Parse(Console.ReadLine());

                        Console.WriteLine("Enter Publisher Name:");
                        book.Publisher = Console.ReadLine();
                        bookOperation.AddBook(book);
                        break;
                    case 3:
                        Address address = new Address();

                        address.AddressId = new Random().Next(0, 999);
                        
                        Console.WriteLine("List of Aurthor Id:");
                        aurthorId = aurthorOperation.GetAurthorId();
                        if (aurthorId.Count > 0)
                        {
                            Console.WriteLine("List of available aurthor");
                            foreach (var item in aurthorId)
                            {
                                Console.WriteLine("Aurthor Id: {0}", item);
                            }
                        }
                        Console.WriteLine("Enter Aurthor Id from available aurthors to add new address :");
                        address.AurthorId = int.Parse(Console.ReadLine());
                        Console.WriteLine("Enter Country Name:");
                        address.Country = Console.ReadLine();
                        Console.WriteLine("Enter City:");
                        address.City = Console.ReadLine();
                        addressOperation.AddAddress(address);
                        break;
                    case 4:
                        Aurthor aurthor = new Aurthor();
                        Console.Write("Available aurthors are:");
                        List<int> aurthorIds = new List<int>();
                        Console.WriteLine("List of Aurthor Id:");
                        aurthorId = aurthorOperation.GetAurthorId();
                        if (aurthorId.Count > 0)
                        {
                            Console.WriteLine("List of available aurthor");
                            foreach (var item in aurthorId)
                            {
                                Console.WriteLine("Aurthor Id: {0}", item);
                            }
                        }
                        Console.WriteLine("Enter Aurthor Id from available aurthors to add new address :");
                        aurthor.AurthorId = int.Parse(Console.ReadLine());
                        foreach (var item in AllData.AurthorData)
                        {
                            if (aurthor.AurthorId == item.AurthorId)
                            {
                                Console.WriteLine("Enter Aurthor Name:");
                                aurthor.Name = Console.ReadLine();
                                Console.WriteLine("Enter Aurthor Age:");
                                aurthor.Age = int.Parse(Console.ReadLine());
                                aurthorOperation.UpdateAurthor(aurthor);
                                Console.WriteLine("Aurthor successfully updated");
                            }
                        }
                        break;
                    case 6:
                       
                        List<AurthorBookDetail> authDeatil = new List<AurthorBookDetail>();
                        Console.WriteLine("Aurthor Details are:");
                        authDeatil = aurthorOperation.GetAurthorDetail();
                        foreach (var item in authDeatil)
                        {
                            Console.WriteLine("aurthor Name: {0}\t Total Books: {1}", item.Name, item.Count);
                        }
                        break;
                    case 7:
                        Console.WriteLine("Total Books records:");
                        List<Book> bookDetails = new List<Book>();
                        bookDetails = bookOperation.GetBookDetails();
                        Console.WriteLine("Total Books Details");
                        foreach (var item in bookDetails)
                        {
                            Console.WriteLine("Book Id: {0} \t Name: {1} \t AurthorId: {2} \t Publisher: {3}", item.BookId, item.BookName, item.AurthorId, item.Publisher);
                        }
                        break;
                    case 8:
                        List<AurthorAddressDetail> aurthorAddressDetail=new List<AurthorAddressDetail>();
                        Console.WriteLine("Total address record");
                        aurthorAddressDetail = addressOperation.GetBookDetails();
                        foreach (var item in aurthorAddressDetail)
                        {
                            Console.WriteLine("Aurthor: {0}\t Country: {1}\t City: {2}", item.AurthorName, item.Country, item.City);
                        }
                        break;

                }



            }
            while (operationChoice != 0);

        }



        private void AddAddress(int aurthorId)
        {
            int addressChoice;
            do
            {
                Address address = new Address();
                address.AurthorId = aurthorId;
                Console.WriteLine("Enter Country:");
                address.Country = Console.ReadLine();
                Console.WriteLine("Enter City:");
                address.City = Console.ReadLine();
                //aurthorBookOperation.AddAddress(address);
                Console.WriteLine("Press 1 to add another of aurthor Id {0} Address", aurthorId);
                addressChoice = int.Parse(Console.ReadLine());
            }
            while (addressChoice == 1);
        }

        private Book AddBook(int aurthorId)
        {
            Book book = new Book();
            book.AurthorId = aurthorId;
            Console.WriteLine("Enter Book Id: ");
            book.BookId = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter Book Name: ");
            book.BookName = Console.ReadLine();
            return book;

        }
        private Aurthor AurthorInput()
        {
            Aurthor aurthor = new Aurthor();
            Console.WriteLine("Enter Aurthor Id:");
            aurthor.AurthorId = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter Aurthor Name:");
            aurthor.Name = Console.ReadLine();
            Console.WriteLine("Enter Aurthor Age");
            aurthor.Age = int.Parse(Console.ReadLine());
            return aurthor;
        }
    }
}
