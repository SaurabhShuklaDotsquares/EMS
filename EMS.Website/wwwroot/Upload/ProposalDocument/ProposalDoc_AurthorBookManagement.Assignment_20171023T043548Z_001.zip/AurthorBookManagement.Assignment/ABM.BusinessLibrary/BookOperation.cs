﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ABM.Data;
namespace ABM.BusinessLibrary
{
   public class BookOperation
    {
        public void AddBook(Book book)
        {
            AllData.BookData.Add(book);
        }

        public List<Book> GetBookDetails()
        {
           List<Book> bookDetails=new List<Book>();

           foreach (var item in AllData.BookData)
           {
               bookDetails.Add(item);
           }
           return bookDetails;
        }

    }
}
