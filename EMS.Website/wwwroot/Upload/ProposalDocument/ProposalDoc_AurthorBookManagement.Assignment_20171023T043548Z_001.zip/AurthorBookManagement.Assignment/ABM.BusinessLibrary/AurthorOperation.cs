﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ABM.Data;

namespace ABM.BusinessLibrary
{
    public class AurthorOperation
    {
        public void AddAurthor(AurthorDataClass aurthorDataClass)
        {
            AllData.AurthorData.Add(aurthorDataClass.aurthor);
            AllData.AddressData.Add(aurthorDataClass.address);
            AllData.BookData.Add(aurthorDataClass.book);
        }

        public List<int> GetAurthorId()
        {
            List<int> aurthorId = new List<int>();
            foreach (var item in AllData.AurthorData)
            {
                aurthorId.Add(item.AurthorId);
            }
            return aurthorId;
        }

        public bool CheckaurthorId(int id)
        {
            bool result=false;
            List<int> aurthorId = new List<int>();
            foreach (var item in AllData.AurthorData)
            {
                if (item.AurthorId == id)
                {
                    result = true;
                }
            }
            return result;
        }

        public void UpdateAurthor(Aurthor aurthor)
        {
            foreach (var item in AllData.AurthorData)
            {
                if (aurthor.AurthorId == item.AurthorId)
                {
                    item.Name = aurthor.Name;
                    item.Age = aurthor.Age;
                }
            }
        }

        public List<AurthorBookDetail> GetAurthorDetail()
        {

            List<AurthorBookDetail> autherDataBookList = new List<AurthorBookDetail>();

            AllData.AurthorData.ForEach(a =>
            {
                autherDataBookList.Add(new AurthorBookDetail
                {
                    Name = a.Name,
                    Count = AllData.BookData.Count(b => b.AurthorId == a.AurthorId)
                });
            });

            return autherDataBookList;
        }     
    }



    public class AurthorBookDetail
    {
        public string Name { get; set; }
        public int Count { get; set; }
    }
}
