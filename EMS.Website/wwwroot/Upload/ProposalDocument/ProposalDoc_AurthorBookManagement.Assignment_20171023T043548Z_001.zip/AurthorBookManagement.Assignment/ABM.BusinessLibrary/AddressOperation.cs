﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ABM.Data;
namespace ABM.BusinessLibrary
{
    public class AddressOperation
    {   
        public void AddAddress(Address address)
        {
            AllData.AddressData.Add(address);
        }

        public List<AurthorAddressDetail> GetBookDetails()
        {
            List<AurthorAddressDetail> aurtherAddressList = new List<AurthorAddressDetail>();
            var groupedResult = from au in AllData.AurthorData
                                join ad in AllData.AddressData on au.AurthorId equals ad.AurthorId
                                select new { au.Name, ad.Country,ad.City };        
            foreach (var item in groupedResult)
            {
                AurthorAddressDetail aurthorAddressDetail = new AurthorAddressDetail();
                aurthorAddressDetail.AurthorName = item.Name;
                aurthorAddressDetail.Country = item.Country;
                aurthorAddressDetail.City=item.City;
                aurtherAddressList.Add(aurthorAddressDetail);
             
            }

            //List<AurthorAddressDetail> aurtherAddressList = new List<AurthorAddressDetail>();

            //AllData.AddressData.ForEach(a =>
            //{
            //    aurtherAddressList.Add(new AurthorAddressDetail
            //    {
            //        AurthorName = AllData.AurthorData.Where(b=>b.AurthorId==a.AurthorId);
            //        Country = 
            //    });
            //});

            return aurtherAddressList;
        }     
        
    }
    public class AurthorAddressDetail
    {
        public string AurthorName { get; set; }
        public string Country { get; set; }
        public string City { get; set; }
    }
}
